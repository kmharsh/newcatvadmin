
import React, { useState } from 'react';

import Table from '../inputComponent/table'; // Corrected Table import

import PayementData from '../../PayementData.json';
import { faTrashAlt, faEye, faEdit } from '@fortawesome/free-solid-svg-icons';
const Payment = () => {
    // Define fixed columns and default user table header
    const fixedColumns = ["Sr"];
    const ActionColumns = ["Action"]
    const defaultUserTableHeader = ["WOITransactionID","AccountNo", "TranStatus", "PGName", "TotalPaymentAmount", "ObrmSubmit", "ObrmPlanActivate", "UpassUpdate", "transactionLimit", "created_at"];

    // Combine fixed columns and user table header
    const mergedUserTableHeader = [...fixedColumns, ...defaultUserTableHeader, ...ActionColumns];
    const UserhandleView = (PayementData) => {
        console.log("view button", PayementData);
        window.location.href = `/PaymentViewComponent`;
    };

    const UserhandleEdit = (userName) => {
        console.log("edit button", userName);
    };

    const UserhandleDelete = (userName) => {
        console.log("delete button", userName);
    };


    const filterSubmit = () => {
        console.log("filter submitted")
    }
    return (
        <div className='container'>
            <div className="table-responsive">
                <Table
                    userData={PayementData}
                    headers={mergedUserTableHeader}
                    sr={true}
                    action={1}
                    actionButtons={[
                        { action: 'view', icon: faEye, label: 'View', cssClass: 'btn btn-primary rounded font-weight-bolder mx-2 text-center', onClick: UserhandleView },
                        // { action: 'edit', icon: faEdit, label: 'Edit', cssClass: 'btn btn-warning rounded font-weight-bolder mx-2 text-center', onClick: UserhandleEdit },
                        // { action: 'delete', icon: faTrashAlt, label: 'Delete', cssClass: 'btn btn-danger rounded fontweightbolder mx-2 text-center', onClick: UserhandleDelete }

                    ]}
                    pagination={true}
                    rowsCountSelctor={true}
                    totalDbRows={100000000}
                    filter={true}
                    filterOptions={
                        [
                            {
                                level: "Account Number",
                                type: "number",
                                className: "form-control mt-3",
                                id: "",
                                onChange: null,
                                placeholder: "Enter Account Number"
                            },
                            {
                                level: "dateRange",
                                type: "dateRange",
                                className: "form-control mt-3",
                                id: "",
                                onChange: null,
                                placeholder: "Enter Phone"
                            },
                            {
                                level: "payment getway",
                                type: "select",
                                className: "form-control mt-4 w-25",
                                id: "",
                                onChange: null,
                                placeholder: "",
                                options: [
                                    { label: 'All', value: '' },
                                    { label: 'paytm', value: 'paytm' },
                                    { label: 'Billdesk', value: 'Billdesk' },
                                ]
                            }
                        ]
                    }
                    addButton={false}
                    onSubmitfilter={filterSubmit}
                />
            </div>
        </div>
    );
};

export default Payment;

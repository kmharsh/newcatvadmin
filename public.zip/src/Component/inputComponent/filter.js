import React, { useState } from 'react';
import InputField from '../inputComponent/InputField';
import SelectBox from '../inputComponent/SelectBox';

const TableDataFilter = ({ filterOptions, onSubmit }) => {

    const [formData, setFormData] = useState({});

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    const getFormData = () => {
        return formData;
    };

    return (
        <form onSubmit={handleSubmit} className='form-group w-100 d-flex align-items-end justify-content-start'>
            {filterOptions.map((option) => {
                switch (option.type) {
                    case 'text':
                        return (
                            <InputField
                                key={option.name}
                                type="text"
                                name={option.name}
                                id={option.id}
                                className={option.className}
                                placeholder={option.placeholder}
                                value={formData[option.name] || ''}
                                onChange={handleChange}
                            />
                        );
                    case 'email':
                        return (
                            <InputField
                                key={option.name}
                                type="email"
                                name={option.name}
                                id={option.id}
                                className={option.className}
                                placeholder={option.placeholder}
                                value={formData[option.name] || ''}
                                onChange={handleChange}
                            />
                        );
                    case 'number':
                        return (
                            <InputField
                                key={option.name}
                                type="number"
                                name={option.name}
                                id={option.id}
                                className={option.className}
                                placeholder={option.placeholder}
                                value={formData[option.name] || ''}
                                onChange={handleChange}
                            />
                        );
                    case 'select':
                        return (
                            <select
                                key={option.name}
                                name={option.name}
                                id={option.id}
                                className={option.className}
                                value={formData[option.name] || ''}
                                onChange={handleChange}
                            >
                                {formData[option.name] && <option value="">{option.placeholder}</option>}

                                {option.options && option.options.map((opt, index) => (
                                    <option key={index} value={opt.value}>
                                        {opt.label}
                                    </option>
                                ))}
                            </select>
                        );
                    case 'date':
                        return (
                            <InputField
                                key={option.name}
                                type="date"
                                name={option.name}
                                id={option.id}
                                className={option.className}
                                value={formData[option.name] || ''}
                                onChange={handleChange}
                            />
                        );
                    case 'dateRange':
                        return (
                            <React.Fragment key={option.name}>
                                <InputField
                                    type="date"
                                    name={option.name + "_start"}
                                    id={option.id + "_start"}
                                    className={option.className + "-start"}
                                    value={formData[option.name + "_start"] || ''}
                                    onChange={handleChange}
                                />
                                
                                <InputField
                                    type="date"
                                    name={option.name + "_end"}
                                    id={option.id + "_end"}
                                    className={option.className + "-end"}
                                    value={formData[option.name + "_end"] || ''}
                                    onChange={handleChange}
                                />
                            </React.Fragment>
                        );
                    default:
                        return null;
                }
            })}
            <button type="submit" className="btn-custom btn btn-success"><img src="./images/faces-clipart/search.png" alt="search" /></button>
        </form>
    );
};

export default TableDataFilter;

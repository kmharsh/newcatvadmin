import React, { useState } from 'react';

const SelectBox = ({ label, options, value, onChange }) => {
    return (
        <div className="form-group mt-3">
            <label>{label}</label>
            <select value={value} onChange={onChange} className="form-control">
                {options?.map(option => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                ))}
            </select>
        </div>
    );
};

export default SelectBox;

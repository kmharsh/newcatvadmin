import React, { useState } from 'react';
import ValidationComponent from '../ValidationComponent/ValidationComponent';

const InputField = ({ label, name, type, value, onChange, placeholder, required }) => {
    const [isDirty, setIsDirty] = useState(false);

    const handleBlur = () => {
        setIsDirty(true);
    };

    return (
        <div className="from-wrp">
            <label className="label" htmlFor={name}>{label}</label>
            <input
                type={type}
                name={name}
                value={value}
                onChange={onChange}
                onBlur={handleBlur} 
                className="form-control"
                placeholder={placeholder}
                required={required}
            />
            {isDirty && (
                <ValidationComponent
                    value={value} 
                    rules={{ required: true, maxlength: 10, pattern: /^[0-9]+$/ }}
                />
            )}
        </div>
    );
}

export default InputField;
